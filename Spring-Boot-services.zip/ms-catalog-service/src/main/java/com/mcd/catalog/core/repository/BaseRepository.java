package com.mcd.catalog.core.repository;

import org.springframework.stereotype.Repository;

@Repository
public  class BaseRepository {

	public String getName() {
		return "Rajaram";

	}
}
