package com.mcd.catalog.adaptor.rest.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public interface CatalogRestController {

}
